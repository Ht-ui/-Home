#!/usr/bin/env python3
"""
竹子のHome - 本地视频库服务器 V8.0
"""

import os
import sys
import sqlite3
import json
import time
import threading
import atexit
import socket
import http.server
import socketserver
from urllib.parse import urlparse, unquote, parse_qs
from datetime import datetime
import re
import base64
import uuid
import shutil

# 配置日志
import logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class ResourceManager:
    """资源管理器 - 稳健设计"""
    _instance = None
    _lock = threading.Lock()
    
    def __new__(cls):
        with cls._lock:
            if cls._instance is None:
                cls._instance = super(ResourceManager, cls).__new__(cls)
                cls._instance._initialized = False
        return cls._instance
    
    def __init__(self):
        if not hasattr(self, '_initialized') or not self._initialized:
            self._initialized = True
            self._resources_ready = threading.Event()
            self.base_dir = os.path.dirname(os.path.abspath(__file__))
            self.video_dir = os.path.join(self.base_dir, "videos")
            self.thumbnail_dir = os.path.join(self.base_dir, "thumbnails")
            self.db_path = os.path.join(self.base_dir, "video_library.db")
            
            # 立即初始化资源
            self.initialize_resources()
    
    def initialize_resources(self):
        """初始化资源 - 同步稳健初始化"""
        try:
            logger.info("初始化服务器资源...")
            
            # 1. 初始化目录
            self._init_directories()
            
            # 2. 初始化数据库
            self._init_database()
            
            # 3. 标记资源就绪
            self._resources_ready.set()
            logger.info("服务器资源初始化完成")
            return True
            
        except Exception as e:
            logger.error("资源初始化失败: %s", e)
            return False
    
    def _init_directories(self):
        """初始化目录结构"""
        for d in [self.video_dir, self.thumbnail_dir]:
            if not os.path.exists(d):
                os.makedirs(d)
                logger.info("创建目录: %s", d)
    
    def _init_database(self):
        """初始化数据库"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS videos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                year INTEGER,
                series TEXT,
                filename TEXT NOT NULL,
                filepath TEXT NOT NULL,
                thumbnail_path TEXT,
                file_size INTEGER,
                duration REAL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(filepath)
            )
        ''')
        conn.commit()
        conn.close()
    
    def are_resources_ready(self):
        """检查资源是否就绪"""
        return self._resources_ready.is_set()
    
    def wait_for_resources(self, timeout=30):
        """等待资源就绪"""
        return self._resources_ready.wait(timeout)
    
    def get_db_connection(self):
        """获取数据库连接"""
        if not self.wait_for_resources():
            raise RuntimeError("服务器资源未就绪")
        
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

class VideoLibraryHandler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        self.resource_manager = ResourceManager()
        self.base_dir = self.resource_manager.base_dir
        
        # 确保资源初始化完成
        if not self.resource_manager.wait_for_resources():
            logger.error("服务器资源初始化超时")
        
        # 调用父类初始化
        super().__init__(*args, directory=self.base_dir, **kwargs)
    
    def do_HEAD(self):
        """处理HEAD请求 - 稳健简化：返回基本头部，避免复杂操作"""
        try:
            # 简化处理：只设置基本头部，立即返回
            self.send_response(200)
            self.send_header('Content-Length', '0')
            self.end_headers()
        except Exception as e:
            # 静默处理错误
            logger.debug("HEAD请求简化处理: %s", e)
            try:
                self.send_error(200)
            except:
                pass
    
    def do_GET(self):
        """处理GET请求 - 稳健处理"""
        try:
            if not self.check_resources_ready():
                return
                
            path = unquote(urlparse(self.path).path)
            
            if path == '/api/status':
                self.handle_api_status()
            elif path == '/api/videos':
                self.get_all_videos()
            elif path.startswith('/api/videos/') and path.split('/')[-1].isdigit():
                video_id = int(path.split('/')[-1])
                self.get_video(video_id)
            elif path.startswith('/videos/'):
                self.serve_video_file_safe(path)
            elif path.startswith('/thumbnails/'):
                filename = unquote(path.split('/')[-1])
                self.serve_thumbnail_file(filename)
            elif path == '/api/random-thumbnail':
                self.serve_random_thumbnail()
            elif path == '/':
                self.serve_index()
            elif path == '/video_library.html':
                self.serve_video_library()
            else:
                self.serve_static_file(path)
                
        except Exception as e:
            logger.error("GET请求错误: %s", e)
            self.send_error(500, "Server error")
    
    def do_POST(self):
        """处理POST请求"""
        try:
            if not self.check_resources_ready():
                return
                
            content_length = int(self.headers.get('Content-Length', 0))
            path = unquote(urlparse(self.path).path)
            
            if content_length == 0:
                self.send_error(400, "No data provided")
                return
                
            post_data = self.rfile.read(content_length)
            data = json.loads(post_data.decode('utf-8'))
            
            if path == '/api/videos':
                self.add_video(data)
            elif path == '/api/videos/batch':
                self.batch_add_videos(data)
            elif path == '/api/videos/batch/delete':
                self.batch_delete_videos(data)
            elif path == '/api/videos/batch/update':
                self.batch_update_videos(data)
            elif path == '/api/videos/upload-thumbnail':
                self.upload_thumbnail(data)
            else:
                self.send_error(404, "Not found")
                
        except Exception as e:
            logger.error("POST请求错误: %s", e)
            self.send_error(500, "POST error")
    
    def do_PUT(self):
        """处理PUT请求"""
        try:
            if not self.check_resources_ready():
                return
                
            path = unquote(urlparse(self.path).path)
            if path.startswith('/api/videos/') and path.split('/')[-1].isdigit():
                video_id = int(path.split('/')[-1])
                content_length = int(self.headers.get('Content-Length', 0))
                if content_length == 0:
                    self.send_error(400, "No data provided")
                    return
                    
                post_data = self.rfile.read(content_length)
                data = json.loads(post_data.decode('utf-8'))
                self.update_video(video_id, data)
            else:
                self.send_error(404, "Not found")
        except Exception as e:
            logger.error("PUT请求错误: %s", e)
            self.send_error(500, "PUT error")
    
    def do_DELETE(self):
        """处理DELETE请求"""
        try:
            if not self.check_resources_ready():
                return
                
            path = unquote(urlparse(self.path).path)
            if path.startswith('/api/videos/') and path.split('/')[-1].isdigit():
                video_id = int(path.split('/')[-1])
                self.delete_video(video_id)
            else:
                self.send_error(404, "Not found")
        except Exception as e:
            logger.error("DELETE请求错误: %s", e)
            self.send_error(500, "DELETE error")
    
    def check_resources_ready(self):
        """检查资源是否就绪"""
        if not self.resource_manager.are_resources_ready():
            self.send_error(503, "服务器资源初始化中，请稍后重试")
            return False
        return True
    
    def handle_api_status(self):
        """处理API状态检查"""
        try:
            hostname = socket.gethostname()
            local_ip = socket.gethostbyname(hostname)
            response = {
                'status': 'online',
                'version': '1.55',
                'timestamp': datetime.now().isoformat(),
                'server_ip': local_ip,
                'server_port': self.server.server_address[1],
                'resources_ready': self.resource_manager.are_resources_ready()
            }
            self.send_json_response(200, response)
        except Exception as e:
            self.send_json_response(500, {'error': str(e)})
    
    def get_all_videos(self):
        """获取所有视频"""
        try:
            query_params = parse_qs(urlparse(self.path).query)
            search = query_params.get('search', [''])[0]
            year_filter = query_params.get('year', [''])[0]
            series_filter = query_params.get('series', [''])[0]
            
            conn = self.resource_manager.get_db_connection()
            cursor = conn.cursor()
            
            where_conditions = []
            params = []
            
            if search:
                where_conditions.append("(title LIKE ? OR series LIKE ? OR year LIKE ?)")
                search_term = f"%{search}%"
                params.extend([search_term, search_term, search_term])
            
            if year_filter:
                where_conditions.append("year = ?")
                params.append(int(year_filter))
            
            if series_filter:
                where_conditions.append("series = ?")
                params.append(series_filter)
            
            where_clause = ""
            if where_conditions:
                where_clause = "WHERE " + " AND ".join(where_conditions)
            
            query = f'SELECT * FROM videos {where_clause} ORDER BY created_at DESC'
            cursor.execute(query, params)
            
            videos = []
            for row in cursor.fetchall():
                video_dict = dict(row)
                
                random_param = int(time.time())
                if video_dict.get('thumbnail_path'):
                    video_dict['thumbnail_url'] = f"/thumbnails/{video_dict['thumbnail_path']}?t={random_param}"
                else:
                    video_dict['thumbnail_url'] = f"https://www.loliapi.com/acg/?type=image&random={random_param}"
                
                videos.append(video_dict)
            
            conn.close()
            
            response = {
                'videos': videos,
                'total': len(videos)
            }
            self.send_json_response(200, response)
            
        except Exception as e:
            logger.error("获取视频列表错误: %s", e)
            self.send_error(500, "Database error")
    
    def get_video(self, video_id):
        """获取单个视频信息"""
        try:
            conn = self.resource_manager.get_db_connection()
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM videos WHERE id = ?', (video_id,))
            row = cursor.fetchone()
            conn.close()
            
            if row:
                video_dict = dict(row)
                
                random_param = int(time.time()) + video_id
                if video_dict.get('thumbnail_path'):
                    video_dict['thumbnail_url'] = f"/thumbnails/{video_dict['thumbnail_path']}?t={random_param}"
                else:
                    video_dict['thumbnail_url'] = f"https://www.loliapi.com/acg/?type=image&random={random_param}"
                
                self.send_json_response(200, video_dict)
            else:
                self.send_error(404, "Video not found")
        except Exception as e:
            logger.error("获取视频错误: %s", e)
            self.send_error(500, "Database error")
    
    def add_video(self, data):
        """添加单个视频"""
        try:
            required_fields = ['title', 'year', 'series', 'filename', 'filepath']
            for field in required_fields:
                if field not in data or not data[field]:
                    self.send_error(400, f"Missing field: {field}")
                    return
            
            conn = self.resource_manager.get_db_connection()
            cursor = conn.cursor()
            
            existing = conn.execute('SELECT id FROM videos WHERE filepath = ?', (data['filepath'],)).fetchone()
            if existing:
                conn.close()
                self.send_error(409, "Video already exists")
                return
            
            cursor.execute('''
                INSERT INTO videos (title, year, series, filename, filepath)
                VALUES (?, ?, ?, ?, ?)
            ''', (data['title'], int(data['year']), data['series'], data['filename'], data['filepath']))
            
            video_id = cursor.lastrowid
            conn.commit()
            conn.close()
            
            self.send_json_response(200, {'success': True, 'id': video_id, 'message': '视频添加成功'})
        except Exception as e:
            logger.error("添加视频失败: %s", e)
            self.send_error(500, "添加视频失败")
    
    def batch_add_videos(self, data):
        """批量添加视频"""
        try:
            if 'videos' not in data or not isinstance(data['videos'], list):
                self.send_error(400, "Missing videos array")
                return
            
            conn = self.resource_manager.get_db_connection()
            cursor = conn.cursor()
            results = []
            
            for video_data in data['videos']:
                try:
                    if not all(k in video_data for k in ['title', 'year', 'series', 'filename', 'filepath']):
                        continue
                    
                    existing = conn.execute('SELECT id FROM videos WHERE filepath = ?', (video_data['filepath'],)).fetchone()
                    if existing:
                        continue
                    
                    cursor.execute('''
                        INSERT INTO videos (title, year, series, filename, filepath)
                        VALUES (?, ?, ?, ?, ?)
                    ''', (
                        video_data['title'],
                        int(video_data['year']),
                        video_data['series'],
                        video_data['filename'],
                        video_data['filepath']
                    ))
                    results.append(cursor.lastrowid)
                    
                except Exception as e:
                    logger.error("添加视频失败: %s", e)
                    continue
            
            conn.commit()
            conn.close()
            
            self.send_json_response(200, {
                'success': True, 
                'message': f'成功添加 {len(results)} 个视频',
                'added_ids': results
            })
        except Exception as e:
            logger.error("批量添加失败: %s", e)
            self.send_error(500, "批量添加失败")
    
    def update_video(self, video_id, data):
        """更新视频信息"""
        try:
            if not data:
                self.send_error(400, "No data provided")
                return
            
            conn = self.resource_manager.get_db_connection()
            cursor = conn.cursor()
            
            video = conn.execute('SELECT * FROM videos WHERE id = ?', (video_id,)).fetchone()
            if not video:
                conn.close()
                self.send_error(404, "Video not found")
                return
            
            updates = []
            params = []
            
            if 'title' in data and data['title'] is not None:
                updates.append('title = ?')
                params.append(data['title'])
            
            if 'year' in data and data['year'] is not None:
                updates.append('year = ?')
                params.append(int(data['year']))
            
            if 'series' in data and data['series'] is not None:
                updates.append('series = ?')
                params.append(data['series'])
            
            if 'thumbnail' in data and data['thumbnail'] is not None:
                updates.append('thumbnail_path = ?')
                params.append(data['thumbnail'])
            
            if not updates:
                conn.close()
                self.send_error(400, "No valid fields to update")
                return
            
            params.append(video_id)
            query = f'UPDATE videos SET {", ".join(updates)} WHERE id = ?'
            cursor.execute(query, params)
            conn.commit()
            conn.close()
            
            self.send_json_response(200, {'success': True, 'message': '视频更新成功'})
        except Exception as e:
            logger.error("更新视频失败: %s", e)
            self.send_error(500, "更新视频失败")
    
    def delete_video(self, video_id):
        """删除视频"""
        try:
            conn = self.resource_manager.get_db_connection()
            cursor = conn.cursor()
            cursor.execute('DELETE FROM videos WHERE id = ?', (video_id,))
            conn.commit()
            conn.close()
            
            self.send_json_response(200, {'success': True, 'message': '视频删除成功'})
        except Exception as e:
            logger.error("删除视频失败: %s", e)
            self.send_error(500, "删除视频失败")
    
    def batch_delete_videos(self, data):
        """批量删除视频"""
        try:
            if 'video_ids' not in data or not isinstance(data['video_ids'], list):
                self.send_error(400, "Missing video_ids array")
                return
            
            conn = self.resource_manager.get_db_connection()
            cursor = conn.cursor()
            
            placeholders = ','.join(['?' for _ in data['video_ids']])
            cursor.execute(f'DELETE FROM videos WHERE id IN ({placeholders})', data['video_ids'])
            conn.commit()
            conn.close()
            
            self.send_json_response(200, {'success': True, 'message': f'成功删除 {len(data["video_ids"])} 个视频'})
        except Exception as e:
            logger.error("批量删除失败: %s", e)
            self.send_error(500, "批量删除失败")
    
    def batch_update_videos(self, data):
        """批量更新视频"""
        try:
            if 'video_ids' not in data or 'updates' not in data:
                self.send_error(400, "Missing required fields")
                return
            
            video_ids = data['video_ids']
            updates = data['updates']
            
            if not video_ids or not updates:
                self.send_error(400, "Empty data")
                return
            
            conn = self.resource_manager.get_db_connection()
            cursor = conn.cursor()
            
            update_fields = []
            update_params = []
            
            if 'title' in updates and updates['title'] is not None:
                update_fields.append('title = ?')
                update_params.append(updates['title'])
            
            if 'year' in updates and updates['year'] is not None:
                update_fields.append('year = ?')
                update_params.append(int(updates['year']))
            
            if 'series' in updates and updates['series'] is not None:
                update_fields.append('series = ?')
                update_params.append(updates['series'])
            
            if 'thumbnail' in updates and updates['thumbnail'] is not None:
                update_fields.append('thumbnail_path = ?')
                update_params.append(updates['thumbnail'])
            
            if not update_fields:
                conn.close()
                self.send_error(400, "No valid update fields")
                return
            
            placeholders = ','.join(['?' for _ in video_ids])
            query = f'UPDATE videos SET {", ".join(update_fields)} WHERE id IN ({placeholders})'
            params = update_params + video_ids
            
            cursor.execute(query, params)
            conn.commit()
            conn.close()
            
            self.send_json_response(200, {'success': True, 'message': f'成功更新 {len(video_ids)} 个视频'})
        except Exception as e:
            logger.error("批量更新失败: %s", e)
            self.send_error(500, "批量更新失败")
    
    def upload_thumbnail(self, data):
        """上传自定义缩略图"""
        try:
            if 'thumbnail_data' not in data or 'filename' not in data:
                self.send_error(400, "Missing thumbnail data or filename")
                return
            
            thumbnail_data = data['thumbnail_data']
            filename = data['filename']
            
            if ',' in thumbnail_data:
                thumbnail_data = thumbnail_data.split(',')[1]
            
            image_data = base64.b64decode(thumbnail_data)
            
            file_extension = os.path.splitext(filename)[1] or '.jpg'
            thumbnail_filename = f"{uuid.uuid4().hex}{file_extension}"
            thumbnail_path = os.path.join(self.resource_manager.thumbnail_dir, thumbnail_filename)
            
            with open(thumbnail_path, 'wb') as f:
                f.write(image_data)
            
            self.send_json_response(200, {
                'success': True, 
                'message': '缩略图上传成功',
                'thumbnail_path': thumbnail_filename,
                'thumbnail_url': f'/thumbnails/{thumbnail_filename}?t={int(time.time())}'
            })
        except Exception as e:
            logger.error("缩略图上传失败: %s", e)
            self.send_error(500, "缩略图上传失败")
    
    def serve_video_file_safe(self, path):
        """服务视频文件 - 安全版本"""
        try:
            file_path = unquote(path[len('/videos/'):])
            
            if not file_path or '..' in file_path or file_path.startswith('/'):
                self.send_error(400, "Invalid file path")
                return
            
            full_path = os.path.join(self.resource_manager.video_dir, file_path)
            
            if not os.path.exists(full_path) or not os.path.isfile(full_path):
                self.send_error(404, "File not found")
                return
            
            file_size = os.path.getsize(full_path)
            
            range_header = self.headers.get('Range')
            if range_header:
                range_match = re.search(r'bytes=(\d+)-(\d*)', range_header)
                if not range_match:
                    self.send_error(416, "Invalid Range header")
                    return
                
                start = int(range_match.group(1)) if range_match.group(1) else 0
                end = range_match.group(2)
                end = int(end) if end and end != '' else file_size - 1
                
                if start < 0 or end < 0 or start >= file_size or end >= file_size or start > end:
                    self.send_error(416, "Requested Range Not Satisfiable")
                    return
                
                content_length = end - start + 1
                
                self.send_response(206)
                self.send_header('Content-type', 'video/mp4')
                self.send_header('Accept-Ranges', 'bytes')
                self.send_header('Content-Range', f'bytes {start}-{end}/{file_size}')
                self.send_header('Content-Length', str(content_length))
                self.send_cors_headers()
                self.end_headers()
                
                self._transfer_file_safe(full_path, start, content_length)
            else:
                self.send_response(200)
                self.send_header('Content-type', 'video/mp4')
                self.send_header('Content-Length', str(file_size))
                self.send_header('Accept-Ranges', 'bytes')
                self.send_cors_headers()
                self.end_headers()
                
                self._transfer_file_safe(full_path, 0, file_size)
                
        except Exception as e:
            logger.error("视频文件服务错误: %s", e)
            self.send_error(500, "File serve error")
    
    def _transfer_file_safe(self, file_path, start_pos, length):
        """安全文件传输"""
        try:
            with open(file_path, 'rb') as f:
                f.seek(start_pos)
                remaining = length
                chunk_size = 32768
                
                while remaining > 0:
                    current_chunk_size = min(chunk_size, remaining)
                    chunk = f.read(current_chunk_size)
                    if not chunk:
                        break
                    
                    try:
                        self.wfile.write(chunk)
                        self.wfile.flush()
                        remaining -= len(chunk)
                    except (BrokenPipeError, ConnectionResetError, OSError):
                        break
                    
                    if remaining > 0:
                        time.sleep(0.0001)
                        
        except Exception as e:
            logger.error("文件传输错误: %s", e)
            raise
    
    def serve_thumbnail_file(self, filename):
        """服务缩略图文件"""
        try:
            if not filename or '..' in filename or filename.startswith('/'):
                self.send_error(400, "Invalid filename")
                return
            
            file_path = os.path.join(self.resource_manager.thumbnail_dir, filename)
            
            if not os.path.exists(file_path) or not os.path.isfile(file_path):
                self.serve_default_thumbnail()
                return
            
            ext = os.path.splitext(filename)[1].lower()
            if ext == '.png':
                mimetype = 'image/png'
            elif ext == '.gif':
                mimetype = 'image/gif'
            elif ext == '.webp':
                mimetype = 'image/webp'
            else:
                mimetype = 'image/jpeg'
            
            self.serve_file(file_path, mimetype)
        except Exception as e:
            logger.error("提供缩略图失败: %s", e)
            self.serve_default_thumbnail()
    
    def serve_random_thumbnail(self):
        """服务随机缩略图"""
        try:
            self.send_json_response(200, {
                'url': f'https://www.loliapi.com/acg/?type=image&random={int(time.time())}'
            })
        except Exception as e:
            logger.error("随机缩略图错误: %s", e)
            self.send_error(500, "随机缩略图错误")
    
    def serve_index(self):
        """服务首页"""
        self.send_response(302)
        self.send_header('Location', '/video_library.html')
        self.end_headers()
    
    def serve_video_library(self):
        """服务视频库主页面"""
        try:
            file_path = os.path.join(self.base_dir, 'video_library.html')
            if not os.path.exists(file_path):
                self.send_error(404, "video_library.html not found")
                return
            
            self.serve_file(file_path, 'text/html; charset=utf-8')
        except Exception as e:
            logger.error("文件服务错误: %s", e)
            self.send_error(500, "File serve error")
    
    def serve_static_file(self, path):
        """服务静态文件"""
        try:
            if not path or path == '/' or '..' in path or path.startswith('/'):
                self.send_error(404, "File not found")
                return
            
            safe_path = path.lstrip('/')
            file_path = os.path.join(self.base_dir, safe_path)
            
            if not os.path.exists(file_path) or not os.path.isfile(file_path):
                self.send_error(404, "File not found")
                return
            
            ext = os.path.splitext(safe_path)[1].lower()
            if ext == '.html':
                content_type = 'text/html; charset=utf-8'
            elif ext == '.css':
                content_type = 'text/css; charset=utf-8'
            elif ext == '.js':
                content_type = 'application/javascript; charset=utf-8'
            elif ext == '.json':
                content_type = 'application/json; charset=utf-8'
            else:
                content_type = 'application/octet-stream'
            
            self.serve_file(file_path, content_type)
        except Exception as e:
            logger.error("静态文件服务错误: %s", e)
            self.send_error(500, "Static file serve error")
    
    def serve_file(self, file_path, content_type):
        """服务文件"""
        try:
            file_size = os.path.getsize(file_path)
            self.send_response(200)
            self.send_header('Content-type', content_type)
            self.send_header('Content-Length', str(file_size))
            self.send_cors_headers()
            self.end_headers()
            
            with open(file_path, 'rb') as f:
                shutil.copyfileobj(f, self.wfile)
        except Exception as e:
            logger.error("文件服务错误: %s", e)
            self.send_error(500, "File serve error")
    
    def serve_default_thumbnail(self):
        """服务默认缩略图"""
        svg_content = '''<svg width="320" height="180" xmlns="http://www.w3.org/2000/svg">
            <rect width="100%" height="100%" fill="#2d3748"/>
            <text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" 
                  fill="#ffffff" font-family="Arial" font-size="20">No Thumbnail</text>
        </svg>'''
        self.send_response(200)
        self.send_header('Content-type', 'image/svg+xml; charset=utf-8')
        self.send_header('Content-Length', str(len(svg_content)))
        self.send_cors_headers()
        self.end_headers()
        self.wfile.write(svg_content.encode('utf-8'))
    
    def send_json_response(self, status_code, data):
        """发送JSON响应"""
        self.send_response(status_code)
        self.send_header('Content-type', 'application/json; charset=utf-8')
        self.send_cors_headers()
        self.end_headers()
        self.wfile.write(json.dumps(data, ensure_ascii=False).encode('utf-8'))
    
    def send_cors_headers(self):
        """设置CORS头"""
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')

def start_server(port=8080):
    """启动HTTP服务器"""
    handler = VideoLibraryHandler
    
    if not os.path.exists('video_library.html'):
        print("注意: video_library.html 不存在，请确保前端文件在同一目录")
    
    local_ip = socket.gethostbyname(socket.gethostname())
    
    print("=" * 60)
    print("竹子のHome - 本地视频库服务器 V8.0")
    print("=" * 60)
    print("本机IP: " + local_ip)
    print("访问地址: http://" + local_ip + ":" + str(port))
    print("=" * 60)
    
    try:
        with socketserver.TCPServer(("", port), handler) as httpd:
            print("服务器已启动在端口 " + str(port))
            print("前端页面: http://" + local_ip + ":" + str(port) + "/video_library.html")
            print("按 Ctrl+C 停止服务器")
            print("=" * 60)
            
            def cleanup_on_exit():
                httpd.server_close()
                print("服务器已停止，清理完成")
            
            atexit.register(cleanup_on_exit)
            
            httpd.serve_forever()
    except OSError as e:
        if e.errno in (48, 10048):
            print("端口 " + str(port) + " 被占用，尝试 " + str(port + 1))
            return start_server(port + 1)
        else:
            print("服务器启动错误: " + str(e))
            return False
    except KeyboardInterrupt:
        print("服务器已停止")
        return True
    except Exception as e:
        print("意外错误: " + str(e))
        return False

if __name__ == "__main__":
    port = 8080
    if len(sys.argv) > 1:
        try:
            port = int(sys.argv[1])
        except ValueError:
            pass
    
    start_server(port)
